import os
from neo4j import GraphDatabase
from getpass import getpass

URI = input("Enter your Neo4j URI: ").strip()
USERNAME = input("Enter your Neo4j username: ").strip()
PASSWORD = getpass("Enter your Neo4j password: ")

driver = GraphDatabase.driver(
    URI,
    auth=(USERNAME, PASSWORD)
)

try:
    driver.verify_connectivity()
    print("Connected to Neo4j successfully!")

    with driver.session() as session:
        result = session.run(
            "MATCH (p:Person) RETURN p.name AS name, p.goal AS goal"
        )
        for record in result:
            print("Student:", record["name"])
            print("Career goal:", record["goal"])

except Exception as e:
    print("Connection failed:", e)

finally:
    driver.close()